package com.players.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class PlayersModel {
	@Id
	private int sno;
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public int getRuns() {
		return runs;
	}
	public void setRuns(int runs) {
		this.runs = runs;
	}
	public int getFiftys() {
		return fiftys;
	}
	public void setFiftys(int fiftys) {
		this.fiftys = fiftys;
	}
	public int getHundreds() {
		return hundreds;
	}
	public void setHundreds(int hundreds) {
		this.hundreds = hundreds;
	}
	private String name;
	private String team ;
	private int runs;
	private int fiftys;
	private int hundreds;

}
