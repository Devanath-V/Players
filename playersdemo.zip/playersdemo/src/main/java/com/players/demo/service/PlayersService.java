package com.players.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.players.demo.model.PlayersModel;
import com.players.demo.repository.PlayersRepository;

@Service
public class PlayersService {
	@Autowired
	PlayersRepository plRepository;
	
	public List<PlayersModel> getAllPlayers()
	{
		List<PlayersModel> plList=plRepository.findAll();
		return plList;
	}
	public PlayersModel savePlayers(PlayersModel p) {
		return plRepository.save(p);
	}
	public PlayersModel updatePlayers(PlayersModel p) {
		return plRepository.save(p);
	}
	public void deletePlayers(int srno) {
		plRepository.deleteById(srno);
	}
}