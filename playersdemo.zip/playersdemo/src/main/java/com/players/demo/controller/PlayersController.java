package com.players.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.players.demo.model.PlayersModel;
import com.players.demo.service.PlayersService;

@RestController
public class PlayersController {
	@Autowired
	PlayersService plService;
	@GetMapping(value="/fetchPlayers")
	public List<PlayersModel> getAllPlayers(){
		List<PlayersModel> plList=plService.getAllPlayers();
		return plList;
	}
	@PostMapping(value="/savePlayers")
	public PlayersModel savePlayers (@RequestBody PlayersModel p) {
		return plService.savePlayers(p);
	}
	@PutMapping(value="/updatePlayers")
	public PlayersModel updatePlayers (@RequestBody PlayersModel p) {
		return plService.savePlayers(p);
	}
	@DeleteMapping(value="/deletePlayers/{sno}")
	public void deletePlayers (@PathVariable("sno") int srno) {
		plService.deletePlayers(srno);
	}
	
}
